 // ======= TROMBINOSCOPE ======= >>
  var imgList = document.getElementById('imgList');
  var scrollRight = document.getElementById('scroll-right');
  var scrollLeft = document.getElementById('scroll-left');

// Quand on clique sur la flèche de droite,>>
//la barre de scroll se déplace de 750px vers la droite>>
  scrollRight.addEventListener('click', (event) => {
    imgList.scrollBy(750, 0);
});

// Quand on clique sur la flèche de gauche,>>
//la barre de scroll se déplace de 750px vers la gauche>>
  scrollLeft.addEventListener('click', (event) => {
    imgList.scrollBy(-750, 0);
});